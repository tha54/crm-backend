# CRM Backend (FastAPI)

Ce backend minimal est prêt à être déployé sur Render.com.

## Endpoints disponibles
- `/` → Message de bienvenue JSON

## Déploiement sur Render
1. Uploadez ce projet sur un dépôt GitHub.
2. Connectez Render à GitHub.
3. Choisissez ce dépôt et laissez Render utiliser `render.yaml`.