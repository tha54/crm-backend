
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import os
import psycopg2
from psycopg2.extras import RealDictCursor

app = FastAPI()

DB_URL = os.environ.get("DATABASE_URL")

class Client(BaseModel):
    nom: str
    siret: str
    email: str
    telephone: str
    adresse: str

def get_db_connection():
    return psycopg2.connect(DB_URL, cursor_factory=RealDictCursor)

@app.get("/")
def read_root():
    return {"message": "API CRM prête (Render + PostgreSQL)"}

@app.get("/clients")
def list_clients():
    with get_db_connection() as conn:
        cur = conn.cursor()
        cur.execute("SELECT * FROM clients ORDER BY id DESC")
        return cur.fetchall()

@app.post("/clients")
def create_client(client: Client):
    with get_db_connection() as conn:
        cur = conn.cursor()
        cur.execute(
            "INSERT INTO clients (nom, siret, email, telephone, adresse) VALUES (%s, %s, %s, %s, %s) RETURNING id",
            (client.nom, client.siret, client.email, client.telephone, client.adresse)
        )
        client_id = cur.fetchone()["id"]
        conn.commit()
        return {"message": "Client ajouté", "id": client_id}
